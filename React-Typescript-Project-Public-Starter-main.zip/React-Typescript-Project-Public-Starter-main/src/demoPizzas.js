const demoPizzas = [
    {title: 'Pepperoni', price: 320, img: 'pizza-1.jpg', id: 1},
    {title: 'Margarita', price: 400, img: 'pizza-2.jpg', id: 2},
    {title: 'Saussage', price: 531, img: 'pizza-3.jpg', id: 3},
    {title: '3 Cheese', price: 770, img: 'pizza-4.jpg', id: 4},
    {title: 'Veggie', price: 900, img: 'pizza-5.jpg', id: 5},
    {title: 'Mixed', price: 620, img: 'pizza-6.jpg', id: 6},
];

export default demoPizzas;